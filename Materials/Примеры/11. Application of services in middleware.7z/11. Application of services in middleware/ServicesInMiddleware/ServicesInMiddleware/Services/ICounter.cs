﻿namespace ServicesInMiddleware.Services
{
    public interface ICounter
    {
        int Value { get; }
    }
}
