﻿namespace DependencyInjection.Services
{
    public interface IMessageSender
    {
        string Send();
    }
}
